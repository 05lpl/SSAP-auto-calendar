# SSAP-auto-calendar for windows
# 需要安装 python 3.4及以上版本 和 pip

python推荐安装最新版
安装教程如下：  
https://zhuanlan.zhihu.com/p/335220647
按照上面步骤一步步来，不可能安不上。     
python 3.4 及以上版本都预装了 pip   

1.打开schoolpal的我的日程

2.使用Chrome/Edge下载HTML文件 注意选择 网页，全部

3.把“我的日程.html”移动至SSAP-auto-calendar-main文件夹

4.双击start.bat

第一次启动时请双击start_first

5.把export.ics拖动至日历
