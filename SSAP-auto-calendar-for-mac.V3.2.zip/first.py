#!/usr/bin/env python3
import os
from option import options

if __name__ == "__main__":
	os.system("pip3 install beautifulsoup4")
	os.system("pip3 install lxml")
